from __future__ import annotations

from typing import Any, Dict, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
import asyncio

INSIGHTS_MAX_CHARS = 1800

router = APIRouter(prefix="/api/v1/ai", tags=["ai"])


class ExplainRequest(BaseModel):
    kind: str  # "url" | "file"
    data: Dict[str, Any]


class ExplainResponse(BaseModel):
    ok: bool
    summary: str
    guidance: str
    model: Optional[str] = None
    error: Optional[str] = None


def _build_prompt(payload: ExplainRequest) -> str:
    k = payload.kind
    d = payload.data
    if k == "url":
        score = d.get("score")
        level = d.get("level")
        factors = d.get("factors", [])
        http = d.get("http", {})
        dns = d.get("dns", {})
        final_url = http.get("final_url") or d.get("normalized_url") or d.get("input_url")
        parts = [
            "You are a cybersecurity assistant. Provide a short, clear risk summary and actionable guidance.",
            f"Final URL: {final_url}",
            f"Score: {score} (level: {level})",
            f"HTTP: status={http.get('status')} server={http.get('server')} content_type={http.get('content_type')}",
            f"DNS IPs: {', '.join(dns.get('ips', []))}",
            f"Factors: {', '.join(factors)}",
            "Write:",
            "1) A concise summary of risk in 2-4 sentences.",
            "2) 3-6 bullet recommendations for a non-technical user.",
            "Keep to ~150-220 words total. No markdown headings, just paragraphs and plain bullets.",
        ]
        return "\n".join(parts)
    else:
        # file
        score = d.get("score")
        level = d.get("level")
        factors = d.get("factors", [])
        fmt = d.get("format")
        filename = d.get("filename")
        hashes = d.get("hashes", {})
        parts = [
            "You are a cybersecurity assistant. Provide a short, clear risk summary and actionable guidance.",
            f"File: {filename} (format={fmt})",
            f"Score: {score} (level: {level})",
            f"Hashes: sha256={hashes.get('sha256')} sha1={hashes.get('sha1')} md5={hashes.get('md5')}",
            f"Factors: {', '.join(factors)}",
            "Write:",
            "1) A concise summary of risk in 2-4 sentences.",
            "2) 3-6 bullet recommendations for a non-technical user.",
            "Keep to ~150-220 words total. No markdown headings, just paragraphs and plain bullets.",
        ]
        return "\n".join(parts)


def _fallback_summary(payload: ExplainRequest) -> ExplainResponse:
    k = payload.kind
    d = payload.data
    level = d.get("level")
    score = d.get("score")
    factors = d.get("factors", [])
    summary = (
        f"This {'URL' if k == 'url' else 'file'} shows a {level or 'unknown'} risk level (score {score}). "
        f"Key signals: {', '.join(factors) if factors else 'none provided'}. "
        "Review carefully before proceeding."
    )
    guidance = (
        "- Keep software and antivirus up to date.\n"
        "- If unsure, avoid interacting and verify the source.\n"
        "- Use a sandbox or isolated device for suspicious items.\n"
        "- Do not enter credentials on untrusted pages.\n"
        "- When in doubt, consult your security team."
    )
    return ExplainResponse(ok=True, summary=summary, guidance=guidance, model="fallback")


@router.post("/explain", response_model=ExplainResponse)
async def explain(payload: ExplainRequest) -> ExplainResponse:
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return _fallback_summary(payload)

    try:
        import google.generativeai as genai

        genai.configure(api_key=api_key)
        model_name = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
        model = genai.GenerativeModel(model_name=model_name)
        prompt = _build_prompt(payload)
        # Run blocking generation in a thread to avoid blocking event loop
        resp = await asyncio.to_thread(model.generate_content, prompt)
        text = (resp.text or "").strip() if resp else ""
        if not text:
            return _fallback_summary(payload)
        # Attempt to split into summary and guidance
        if "\n- " in text:
            first_line, rest = text.split("\n- ", 1)
            summary = first_line.strip()
            guidance = "- " + rest.strip()
        else:
            # crude split
            parts = text.split("\n\n", 1)
            summary = parts[0][:INSIGHTS_MAX_CHARS]
            guidance = parts[1][:INSIGHTS_MAX_CHARS] if len(parts) > 1 else ""
        return ExplainResponse(ok=True, summary=summary, guidance=guidance, model=model_name)
    except Exception:
        return _fallback_summary(payload)
