from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from app.api.scan import router as scan_router
from app.api.ai import router as ai_router

load_dotenv()

app = FastAPI(title="ALSS Backend", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(scan_router)
app.include_router(ai_router)

@app.get("/health")
async def health() -> JSONResponse:
    return JSONResponse({"status": "ok"})
